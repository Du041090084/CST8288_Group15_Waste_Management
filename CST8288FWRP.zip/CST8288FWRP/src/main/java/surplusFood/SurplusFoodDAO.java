package surplusfood;

import java.util.List;

/**
 * Interface for Data Access Object (DAO) operations on surplus food items.
 */
public interface SurplusFoodDAO {
    /**
     * Creates a new surplus food item.
     * 
     * @param surplusFood the surplus food item to create
     */
    void create(SurplusFood surplusFood);

    /**
     * Reads a surplus food item with the specified ID.
     * 
     * @param surplusFoodId the ID of the surplus food item to read
     * @return the surplus food item with the specified ID, or null if not found
     */
    SurplusFood read(int surplusFoodId);

    /**
     * Updates an existing surplus food item.
     * 
     * @param surplusFood the surplus food item to update
     */
    void update(SurplusFood surplusFood);

    /**
     * Deletes a surplus food item with the specified ID.
     * 
     * @param surplusFoodId the ID of the surplus food item to delete
     */
    void delete(int surplusFoodId);

    /**
     * Retrieves a list of all surplus food items.
     * 
     * @return a list of all surplus food items
     */
    List<SurplusFood> getAllSurplusFood();

    // Add more methods as needed
}
