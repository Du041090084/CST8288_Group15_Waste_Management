package surplusfood;

import java.util.Date;

/**
 * Represents a surplus food item.
 */
public class SurplusFood {
    private int surplusFoodId;
    private String itemName;
    private String itemDescription;
    private int quantity;
    private Date expirationDate;
    private double discountRate;
    private int userId;

    /**
     * Constructs a SurplusFood object with the specified attributes.
     * 
     * @param surplusFoodId the ID of the surplus food item
     * @param itemName the name of the surplus food item
     * @param itemDescription the description of the surplus food item
     * @param quantity the quantity of the surplus food item
     * @param expirationDate the expiration date of the surplus food item
     * @param discountRate the discount rate of the surplus food item
     * @param userId the user ID associated with the surplus food item
     */
    public SurplusFood(int surplusFoodId, String itemName, String itemDescription, int quantity, Date expirationDate, double discountRate, int userId) {
        this.surplusFoodId = surplusFoodId;
        this.itemName = itemName;
        this.itemDescription = itemDescription;
        this.quantity = quantity;
        this.expirationDate = expirationDate;
        this.discountRate = discountRate;
        this.userId = userId;
    }

    // Getters and setters

    /**
     * Gets the ID of the surplus food item.
     * 
     * @return the surplus food item ID
     */
    public int getSurplusFoodId() {
        return surplusFoodId;
    }

    /**
     * Sets the ID of the surplus food item.
     * 
     * @param surplusFoodId the surplus food item ID to set
     */
    public void setSurplusFoodId(int surplusFoodId) {
        this.surplusFoodId = surplusFoodId;
    }

    /**
     * Gets the name of the surplus food item.
     * 
     * @return the surplus food item name
     */
    public String getItemName() {
        return itemName;
    }

    /**
     * Sets the name of the surplus food item.
     * 
     * @param itemName the surplus food item name to set
     */
    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    /**
     * Gets the description of the surplus food item.
     * 
     * @return the surplus food item description
     */
    public String getItemDescription() {
        return itemDescription;
    }

    /**
     * Sets the description of the surplus food item.
     * 
     * @param itemDescription the surplus food item description to set
     */
    public void setItemDescription(String itemDescription) {
        this.itemDescription = itemDescription;
    }

    /**
     * Gets the quantity of the surplus food item.
     * 
     * @return the surplus food item quantity
     */
    public int getQuantity() {
        return quantity;
    }

    /**
     * Sets the quantity of the surplus food item.
     * 
     * @param quantity the surplus food item quantity to set
     */
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    /**
     * Gets the expiration date of the surplus food item.
     * 
     * @return the surplus food item expiration date
     */
    public Date getExpirationDate() {
        return expirationDate;
    }

    /**
     * Sets the expiration date of the surplus food item.
     * 
     * @param expirationDate the surplus food item expiration date to set
     */
    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    /**
     * Gets the discount rate of the surplus food item.
     * 
     * @return the surplus food item discount rate
     */
    public double getDiscountRate() {
        return discountRate;
    }

    /**
     * Sets the discount rate of the surplus food item.
     * 
     * @param discountRate the surplus food item discount rate to set
     */
    public void setDiscountRate(double discountRate) {
        this.discountRate = discountRate;
    }

    /**
     * Gets the user ID associated with the surplus food item.
     * 
     * @return the user ID associated with the surplus food item
     */
    public int getUserId() {
        return userId;
    }

    /**
     * Sets the user ID associated with the surplus food item.
     * 
     * @param userId the user ID associated with the surplus food item to set
     */
    public void setUserId(int userId) {
        this.userId = userId;
    }
}
