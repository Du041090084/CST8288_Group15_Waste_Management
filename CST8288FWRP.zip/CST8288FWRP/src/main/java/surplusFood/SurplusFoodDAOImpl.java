package surplusfood;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.sql.DataSource;

/**
 * Implementation of SurplusFoodDAO for interacting with the database.
 */
public class SurplusFoodDAOImpl implements SurplusFoodDAO {
    private final DataSource dataSource;

    /**
     * Constructs a SurplusFoodDAOImpl with the specified data source.
     * 
     * @param dataSource the data source to be used for database connections
     */
    public SurplusFoodDAOImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(SurplusFood surplusFood) {
        String sql = "INSERT INTO surplus_food (item_name, item_description, quantity, expiration_date, discount_rate, user_id) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, surplusFood.getItemName());
            statement.setString(2, surplusFood.getItemDescription());
            statement.setInt(3, surplusFood.getQuantity());
            statement.setDate(4, new java.sql.Date(surplusFood.getExpirationDate().getTime()));
            statement.setDouble(5, surplusFood.getDiscountRate());
            statement.setInt(6, surplusFood.getUserId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public SurplusFood read(int surplusFoodId) {
        String sql = "SELECT * FROM surplus_food WHERE surplus_food_id = ?";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, surplusFoodId);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return mapSurplusFood(resultSet);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    @Override
    public void update(SurplusFood surplusFood) {
        String sql = "UPDATE surplus_food SET item_name = ?, item_description = ?, quantity = ?, expiration_date = ?, discount_rate = ?, user_id = ? WHERE surplus_food_id = ?";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, surplusFood.getItemName());
            statement.setString(2, surplusFood.getItemDescription());
            statement.setInt(3, surplusFood.getQuantity());
            statement.setDate(4, new java.sql.Date(surplusFood.getExpirationDate().getTime()));
            statement.setDouble(5, surplusFood.getDiscountRate());
            statement.setInt(6, surplusFood.getUserId());
            statement.setInt(7, surplusFood.getSurplusFoodId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(int surplusFoodId) {
        String sql = "DELETE FROM surplus_food WHERE surplus_food_id = ?";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, surplusFoodId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<SurplusFood> getAllSurplusFood() {
        List<SurplusFood> surplusFoodList = new ArrayList<>();
        String sql = "SELECT * FROM surplus_food";

        try (Connection connection = dataSource.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                surplusFoodList.add(mapSurplusFood(resultSet));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return surplusFoodList;
    }

    /**
     * Maps a ResultSet to a SurplusFood object.
     * 
     * @param resultSet the ResultSet containing surplus food data
     * @return a SurplusFood object mapped from the ResultSet
     * @throws SQLException if a database access error occurs
     */
    private SurplusFood mapSurplusFood(ResultSet resultSet) throws SQLException {
        int surplusFoodId = resultSet.getInt("surplus_food_id");
        String itemName = resultSet.getString("item_name");
        String itemDescription = resultSet.getString("item_description");
        int quantity = resultSet.getInt("quantity");
        Date expirationDate = resultSet.getDate("expiration_date");
        double discountRate = resultSet.getDouble("discount_rate");
        int userId = resultSet.getInt("user_id");

        return new SurplusFood(surplusFoodId, itemName, itemDescription, quantity, expirationDate, discountRate, userId);
    }
}
