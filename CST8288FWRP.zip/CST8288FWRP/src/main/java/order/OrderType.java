package order;

/**
 * Enum representing the type of an order.
 * Possible values: PURCHASE, DONATION.
 *
 * @author Yashkaran Singh
 */
public enum OrderType {

    /**
     *
     */
    PURCHASE,

    /**
     *
     */
    DONATION
}
